
---Region-wise Profit
SELECT 
    Region,
    SUM(Profit) AS Region_Profit
FROM ecommerce_sales
GROUP BY Region
ORDER BY Region_Profit DESC;

---Region-wise Sales
SELECT 
    Region,
    SUM(Sales) AS Region_Sales
FROM ecommerce_sales
GROUP BY Region
ORDER BY Region_Sales DESC;