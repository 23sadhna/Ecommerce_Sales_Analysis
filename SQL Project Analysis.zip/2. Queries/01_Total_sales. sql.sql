

----Total Sales
SELECT 
    Product_Name,
    SUM(Sales) AS Total_Sales
FROM ecommerce_sales
GROUP BY Product_Name
ORDER BY Total_Sales DESC;