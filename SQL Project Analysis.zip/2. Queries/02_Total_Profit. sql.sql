

--Total Profit
SELECT 
    SUM(Profit) AS Total_Profit
FROM ecommerce_sales;