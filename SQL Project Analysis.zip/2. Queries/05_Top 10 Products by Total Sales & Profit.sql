

-----Top 10 Products by Total Sales
SELECT TOP 10
    Product_Name,
    SUM(Sales) AS Total_Sales
FROM ecommerce_sales
GROUP BY Product_Name
ORDER BY Total_Sales DESC;

---Top 10 Products by Total Profit
SELECT TOP 10
    Product_Name,
    SUM(Profit) AS Total_Profit
FROM ecommerce_sales
GROUP BY Product_Name
ORDER BY Total_Profit DESC;