

---Time-Based Analysis
---Monthly Sales Trend:
SELECT 
    FORMAT(Order_Date, 'yyyy-MM') AS Month,
    SUM(Sales) AS Monthly_Sales
FROM ecommerce_sales
GROUP BY FORMAT(Order_Date, 'yyyy-MM')
ORDER BY Month;



---Profit Margin Analysis:
SELECT 
    Category,
    SUM(Profit) / NULLIF(SUM(Sales),0) * 100 AS Profit_Margin_Percent
FROM ecommerce_sales
GROUP BY Category;


