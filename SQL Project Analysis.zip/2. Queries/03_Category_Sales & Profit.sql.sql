

---1. Category-wise Profit
SELECT 
    Category,
    SUM(Profit) AS Category_Profit
FROM ecommerce_sales
GROUP BY Category
ORDER BY Category_Profit DESC;

---2. Category-wise Sales
SELECT 
    Category,
    SUM(Sales) AS Category_Sales
FROM ecommerce_sales
GROUP BY Category
ORDER BY Category_Sales DESC;